<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //This part can change the columns of the database table
    
    protected $table='posts';
    public $primaryKey='id';
    public $timestamps=true;

    public function user(){
      return  $this->belongsTo('App\user');
    }
    
    // The above things are used if the infos of the tables are to be changed

}
