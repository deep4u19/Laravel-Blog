<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\members;

class MembersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $members= members::orderBy('fname','asc')->paginate(10);
        return view('/members.index')->with('members',$members);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('members.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'fname'=>'required',
            'lname'=>'required',
            'email'=>'required',
            'details' =>'required'
        ]);
       
        $member=new members;
        $member->fname=$request->input('fname');
        $member->lname=$request->input('lname');
        $member->email=$request->input('email');
        $member->details=$request->input('details');
        $member->save();
        return redirect('/members')->with('success','Member Created');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $members= members::find($id);
        return view('members/show')->with('member',$members);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $members= members::find($id);
        return view('members.edit')->with('members',$members);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
        'fname'=>'required',
        'lname'=>'required',
        'email'=>'required',
        'details'=>'required'  
        ]);
        $members=members::find($id);
        $members->fname=$request->input('fname');
        $members->lname=$request->input('lname');
        $members->email=$request->input('email');
        $members->details=$request->input('details');
        $members->save();

        return redirect('/members')->with('success','Member updated successfully..');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $member= members::find($id);
        $member->delete();
        return redirect('/members')->with('success','Member deleted successfully..');


    }
}
