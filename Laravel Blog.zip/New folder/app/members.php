<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class members extends Model
{
    //Table
    protected $table='members';
    // Primary key
    public $primaryKey='id';
    // Timestamp
    public $timestamps=true;
}
