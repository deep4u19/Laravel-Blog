<?php $__env->startSection('content'); ?>
    <h1>Create Member</h1><hr>
    <?php echo Form::open(['action'=>'MembersController@store', 'method'=>'POST' ]); ?>

    <div class="form-group form-inline ">
        
        <?php echo e(Form::text('fname','',['class'=>'form-control col-md-5','placeholder'=>'Enter Firstname'])); ?>&nbsp;
        
        <?php echo e(Form::text('lname','',['class'=>'form-control col-md-5','placeholder'=>'Enter Lastname'])); ?><br>
        
        <?php echo e(Form::email('email','',['class'=>'form-control col-md-12','placeholder'=>'Enter Email'])); ?><br><br>
         
    </div>
    <?php echo e(Form::textarea('details','',['id'=>'article-ckeditor','class'=>'form-control','placeholder'=>'Enter details'])); ?>

    <?php echo e(Form::reset('Clear',['class'=>'btn btn-primary'])); ?>

        <?php echo e(Form::submit('Submit',['class'=>'btn btn-success'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>