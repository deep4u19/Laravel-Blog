<?php $__env->startSection('content'); ?>
    <a href="/posts" class="btn btn-info">Go Back</a>
    <h1><?php echo e($post->title); ?></h1>
    <div class="row">
    <div class="col-md-6">
    <img style="width:100%;" src="/storage/cover_image/<?php echo e($post->cover_image); ?>" alt="no image">
    </div>
    <div class="col-md-6"><p style="font-size:18px;"><?php echo $post->body; ?></p></div>
    </div><hr>
    <small>Written at <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small><br><br><hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id== $post->user_id): ?>
    <a href="/posts/<?php echo e($post->id); ?>/edit" class='btn btn-primary' >Edit</a>
    <?php echo Form::open(['action'=>['PostController@destroy',$post->id],'method'=>'POST','class'=>'float-right']); ?>

    <?php echo Form::hidden('_method','DELETE'); ?>

    <?php echo Form::submit('Delete',['class'=>'btn btn-danger','onclick'=>"return confirm('Are you sure to delete??')"]); ?>

    <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>