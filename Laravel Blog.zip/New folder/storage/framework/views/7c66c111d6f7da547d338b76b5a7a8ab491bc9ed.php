<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
        <h1>Welcome to the contact page</h1>
        <p>You can contact us from here..</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>