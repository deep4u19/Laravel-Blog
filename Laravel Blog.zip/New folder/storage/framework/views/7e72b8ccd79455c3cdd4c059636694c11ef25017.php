<?php $__env->startSection('content'); ?>
    <h1>Members</h1>
    <?php if(count($members)>0): ?>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="margin-bottom: 10px; padding: 10px;">
        <div class="row">
            <div class="col-md-10" style="padding-top:6px;">
                    
                    <h3><a href="/members/<?php echo e($member->id); ?>"><?php echo e($member->fname); ?>&nbsp;<?php echo e($member->lname); ?> </a></h3>
                    <small>Written at <?php echo e($member->created_at); ?></small>
            </div> 

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($members->links()); ?>

    <?php else: ?>
    <p>No data found</p>
    <?php endif; ?>

    <a href="/members/create" class="btn btn-success">Create Member</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>