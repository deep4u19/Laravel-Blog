<?php $__env->startSection('content'); ?>
<a href="/members" class="btn btn-primary">Back</a>
<h1>Member Name :<?php echo e($member->fname); ?>&nbsp;<?php echo e($member->lname); ?></h1>
<p><?php echo $member->details; ?></p>
<a href="/members/<?php echo e($member->id); ?>/edit" class="btn btn-success float-left">Edit</a>
<?php echo Form::open(['action'=>['MembersController@destroy',$member->id],'method'=>'POST','class'=>'float-right']); ?>

    <?php echo e(Form::hidden('_method','DELETE')); ?>

    <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger','onclick'=>'return confirm("Are you sure to delete??")'])); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>