@extends('layouts.app')
@section('content')
<div class="jumbotron text-center">
        <h1>Welcome to the contact page</h1>
        <p>You can contact us from here..</p>
</div>
@endsection