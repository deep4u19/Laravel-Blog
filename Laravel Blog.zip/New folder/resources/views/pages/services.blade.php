@extends('layouts.app')
@section('content')
        <div class="jumbotron text-center">
        <h1>Welcome to the services page</h1>
        {{-- <h2 >{{ $title }}</h2> --}}
        <ul class=" list-group">
                @if(count($services)>0)      
                        @foreach($services as $service)
                                <li class="list-group-item">{{$service}}</li>
                        @endforeach
                @endif
        </ul>
        </div>
@endsection