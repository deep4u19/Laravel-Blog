@extends('layouts.app')
@section('content')

<div class="jumbotron text-center">
<h1 style="color:cornflowerblue;">{{ $title }}</h1>
<p style="font-size:18px;">This is a simple blog using Laravel.. It has CRUD functionality and also user authentication..</p>
<p><a href="/posts" class="btn btn-primary btn-lg" role="button">See posts</a> </p>
</div>
@endsection