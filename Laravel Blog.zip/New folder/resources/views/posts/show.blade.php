@extends('layouts.app')

@section('content')
    <a href="/posts" class="btn btn-info">Go Back</a>
    <h1>{{$post->title}}</h1>
    <div class="row">
    <div class="col-md-6">
    <img style="width:100%;" src="/storage/cover_image/{{$post->cover_image}}" alt="no image">
    </div>
    <div class="col-md-6"><p style="font-size:18px;">{!!$post->body!!}</p></div>
    </div><hr>
    <small>Written at {{$post->created_at}} by {{$post->user->name}}</small><br><br><hr>
    @if(!Auth::guest())
        @if(Auth::user()->id== $post->user_id)
    <a href="/posts/{{$post->id}}/edit" class='btn btn-primary' >Edit</a>
    {!!Form::open(['action'=>['PostController@destroy',$post->id],'method'=>'POST','class'=>'float-right'])!!}
    {!!Form::hidden('_method','DELETE')!!}
    {!!Form::submit('Delete',['class'=>'btn btn-danger','onclick'=>"return confirm('Are you sure to delete??')"])!!}
    {!!Form::close()!!}
        @endif
    @endif    


@endsection