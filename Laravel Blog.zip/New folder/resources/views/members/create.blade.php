@extends('layouts.app')
@section('content')
    <h1>Create Member</h1><hr>
    {!! Form::open(['action'=>'MembersController@store', 'method'=>'POST' ]) !!}
    <div class="form-group form-inline ">
        {{-- {{ Form::label('fname','Firstname :') }} --}}
        {{ Form::text('fname','',['class'=>'form-control col-md-5','placeholder'=>'Enter Firstname'])}}&nbsp;
        {{-- {{ Form::label('lname','Lastname :')}} --}}
        {{ Form::text('lname','',['class'=>'form-control col-md-5','placeholder'=>'Enter Lastname'])}}<br>
        {{-- {{ Form::label('email','Email :')}} --}}
        {{ Form::email('email','',['class'=>'form-control col-md-12','placeholder'=>'Enter Email'])}}<br><br>
        {{-- {{ Form::label('body','Details :')}} --}} 
    </div>
    {{ Form::textarea('details','',['id'=>'article-ckeditor','class'=>'form-control','placeholder'=>'Enter details'])}}
    {{ Form::reset('Clear',['class'=>'btn btn-primary'])}}
        {{ Form::submit('Submit',['class'=>'btn btn-success'])}}
    {!! Form::close() !!}
@endsection