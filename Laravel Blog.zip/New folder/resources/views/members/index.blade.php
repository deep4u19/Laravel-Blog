@extends('layouts.app')
@section('content')
    <h1>Members</h1>
    @if(count($members)>0)
    @foreach($members as $member)
    <div class="card" style="margin-bottom: 10px; padding: 10px;">
        <div class="row">
            <div class="col-md-10" style="padding-top:6px;">
                    {{-- <h3><a href="/posts/{{$member->id}}">{{$member->fname}}&nbsp;{{$member->lname}} </a></h3> --}}
                    <h3><a href="/members/{{$member->id}}">{{$member->fname}}&nbsp;{{$member->lname}} </a></h3>
                    <small>Written at {{$member->created_at}}</small>
            </div> 

        </div>
    </div>
    @endforeach
    {{$members->links()}}
    @else
    <p>No data found</p>
    @endif

    <a href="/members/create" class="btn btn-success">Create Member</a>
@endsection