@extends('layouts.app')

@section('content')
<a href="/members" class="btn btn-primary">Back</a>
<h1>Member Name :{{$member->fname}}&nbsp;{{$member->lname}}</h1>
<p>{!!$member->details!!}</p>
<a href="/members/{{$member->id}}/edit" class="btn btn-success float-left">Edit</a>
{!! Form::open(['action'=>['MembersController@destroy',$member->id],'method'=>'POST','class'=>'float-right']) !!}
    {{Form::hidden('_method','DELETE')}}
    {{Form::submit('Delete',['class'=>'btn btn-danger','onclick'=>'return confirm("Are you sure to delete??")']) }}
{!! Form::close()!!}

@endsection