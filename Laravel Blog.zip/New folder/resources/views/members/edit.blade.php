@extends('layouts.app')
@section('content')
<h1>Edit member</h1>
    {!! Form::open(['action'=>['MembersController@update',$members->id],'method'=>'POST']) !!}
    <div class="form-group form-inline ">
    {{-- {{ Form::label('fname','Firstname :') }} --}}
    {{ Form::text('fname',$members->fname,['class'=>'form-control col-md-5','placeholder'=>'Enter Firstname'])}}&nbsp;
    {{-- {{ Form::label('lname','Lastname :')}} --}}
    {{ Form::text('lname',$members->lname,['class'=>'form-control col-md-5','placeholder'=>'Enter Lastname'])}}<br>
    {{-- {{ Form::label('email','Email :')}} --}}
    {{ Form::email('email',$members->email,['class'=>'form-control col-md-12','placeholder'=>'Enter Email'])}}<br><br>
    {{-- {{ Form::label('body','Details :')}} --}} 
    </div>
    {{ Form::textarea('details',$members->details,['id'=>'article-ckeditor','class'=>'form-control','placeholder'=>'Enter details'])}}
    {{Form::hidden('_method','PUT')}}
    {{ Form::submit('Update',['class'=>'btn btn-success'])}}



    {!! Form::close()!!}
@endsection